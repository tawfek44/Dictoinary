﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dic
{
    public partial class Form1 : Form
    {
        int pw;
       
        public Form1()
        {
            InitializeComponent(); 
            pw= panel1.Width;
            panel1.Width = 0;
            homeUserControl1.BringToFront();
            searchUserControl1.Visible = false;
            historyUserControl1.Visible = false;
        }
        int panelCounter = 0;
        private void button1_Click(object sender, EventArgs e)
        {
           
            if(panelCounter%2==0)
            {
                timer1.Start();
                timer2.Stop();
            }
            else
            {
                
                timer2.Start();
                timer1.Stop();
                
            }
           panelCounter++;  
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            panel1.Width += 15;
            button1.Image = Image.FromFile(@"E:\Lecture\Lectures\My PRojet\Untitled-3.jpg");
            if (panel1.Width >= pw) { timer1.Stop(); this.Refresh(); }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            panel1.Width -= 15;
            button1.Image = Image.FromFile(@"E:\Lecture\Lectures\My PRojet\Untitled-2.jpg");
            
            if (panel1.Width <= 0) { timer2.Stop(); this.Refresh(); }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            side.Height = button2.Height;
            side.Top = button2.Top;
            historyUserControl1.Visible = false;
            searchUserControl1.Visible = false;
            homeUserControl1.BringToFront();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            side.Height = button3.Height;
            side.Top = button3.Top;
            searchUserControl1.Visible = true;
            historyUserControl1.Visible = false;
            searchUserControl1.BringToFront();
     
        }

        private void button4_Click(object sender, EventArgs e)
        {
            side.Height = button4.Height;
            side.Top = button4.Top;
            historyUserControl1.Visible = true;
            historyUserControl1.BringToFront();
        }
    }
}
